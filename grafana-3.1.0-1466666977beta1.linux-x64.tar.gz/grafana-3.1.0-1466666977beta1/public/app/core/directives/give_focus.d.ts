/// <reference path="../../../../public/app/headers/common.d.ts" />
declare var _default: {};
export default _default;
