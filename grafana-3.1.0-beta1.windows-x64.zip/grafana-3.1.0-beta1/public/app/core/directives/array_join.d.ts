/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare function arrayJoin(): {
    restrict: string;
    require: string;
    link: (scope: any, element: any, attr: any, ngModel: any) => void;
};
