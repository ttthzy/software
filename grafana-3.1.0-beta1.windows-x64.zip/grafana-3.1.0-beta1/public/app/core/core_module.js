/*! grafana - v3.1.0-beta1 - 2016-06-23
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["angular"],function(a){var b;return{setters:[function(a){b=a}],execute:function(){a("default",b["default"].module("grafana.core",["ngRoute"]))}}});