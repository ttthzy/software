///<reference path="../../headers/common.d.ts" />

import coreModule from 'app/core/core_module';

export class DashListCtrl {
  /** @ngInject */
  constructor() {
  }
}

coreModule.controller('DashListCtrl', DashListCtrl);
