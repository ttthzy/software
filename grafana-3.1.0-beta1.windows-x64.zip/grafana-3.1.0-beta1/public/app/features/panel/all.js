/*! grafana - v3.1.0-beta1 - 2016-06-23
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panel_menu","./panel_directive","./solo_panel_ctrl","./query_ctrl","./panel_editor_tab","./query_editor_row","./metrics_ds_selector"],function(){});