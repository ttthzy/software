# Chronograf 0.3

## Usage

If you installed Chonograf via a .deb or .rpm package, you should be able to simply run `sudo service chronograf start`.
The Chronograf startup script needs root permission to ensure that it can write to /var/log, but the actual executable runs as a normal user.

If you did not install Chronograf via a package, you can just directly run the executable, e.g. `/opt/chronograf/chronograf`.

### Command-line options

Chronograf exposes two command line flags: `-sample-config` which prints out a sample configuration and `-config` which specifies the path to your configuration file.

See the sample configuration for more details on what is configurable.

If you installed Chronograf via a package, you already have a config file at `/opt/chronograf/config.toml` where you can change settings.
